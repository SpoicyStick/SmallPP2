from flask import Flask, render_template, request, url_for, redirect, session, escape
from hashlib import md5
import pymysql, hashlib
import os
#from flaskext.mysql import MySQL
app = Flask(__name__)
app.secret_key="pp"
# Make the WSGI interface available at the top level so wfastcgi can get it.
wsgi_app = app.wsgi_app
# Connect to the database
def create_connection():
    return pymysql.connect(host='localhost',
                             user='root',
                             password='13COM',
                             db='pbase',
                             charset='utf8mb4'
                             ,cursorclass=pymysql.cursors.DictCursor)

class ServerError(Exception):
	pass

#display users
@app.route('/')
def home():
	if session.get('logged_in'):
		username_session=session['username']
		return render_template("index.html", session_user_name=username_session)

	username_session=""
	return render_template("index.html")

	connection=create_connection()
	try:
		with connection.cursor() as cursor:
			sql = "SELECT * from users"
			cursor.execute(sql)
			data = cursor.fetchall()
			data=list(data)
	finally:
			connection.close()


	return render_template("index.html", results=data)

@app.route('/users')
def users():
	if session.get('logged_in'):
		username_session=escape(session['username']).capitalize()
		connection=create_connection()
		try:
			with connection.cursor() as cursor:
				sql = "SELECT * from users"
				cursor.execute(sql)
				data = cursor.fetchall()
				data=list(data)
		finally:
			connection.close()
		return render_template("users.html", session_user_name=username_session, results=data)

	username_session=""
	return render_template("index.html")

@app.route('/workshops')
def workshops():
	if session.get('logged_in'):
		username_session=escape(session['username']).capitalize()
		connection=create_connection()
		try:
			with connection.cursor() as cursor:
				sql = "SELECT * from workshops"
				cursor.execute(sql)
				data = cursor.fetchall()
				data=list(data)
		finally:
			connection.close()
		return render_template("Workshops.html", session_user_name=username_session, results=data)

	username_session=""
	return render_template("index.html")



# update from form
@app.route('/add_user', methods=['POST','GET'])
def new_user():
   connection=create_connection()
   if request.method == 'POST':
         form_values = request.form 
         first_name = form_values["firstname"]
         family_name = form_values["familyname"]
         email = form_values["email"]
         username = form_values["username"]
         password = form_values["password"]
         roleid = form_values[1]
         dob="2001-10-01"
         try:
            with connection.cursor() as cursor:
                # Create a new record
                print('1')
                sql ="INSERT INTO `users` (FirstName,FamilyName,Email,DateOfBirth,Password,Username,RoleID) VALUES (%s,%s,%s,%s,%s,%s,%s)"
                print('2')
                val =(first_name,family_name,email,dob,password,username,1)
                print('3')
                cursor.execute(sql,(val))
                print('4')
                #save values in dbase
            connection.commit()
            cursor.close()
            with connection.cursor() as cursor:
                #pull records and display
                sql = "SELECT * from users"
                cursor.execute(sql)
                data = cursor.fetchall()
                data=list(data)
         finally:
             connection.close()
             return redirect(url_for('users'))
   return render_template("add_user.html")


@app.route('/edit_record', methods=['POST','GET'])
def update_user():
	user_id = request.args.get('id')
	connection=create_connection()
	if request.method == 'POST':
			form_values = request.form 
			first_name = form_values.get("firstname")
			family_name = form_values.get("familyname")
			email = form_values.get("email")
			password = form_values.get("password")
			dob="2001-10-01"
			user_id = form_values.get('Id')
			try:
				with connection.cursor() as cursor:
					# Create a new record
					sql = "UPDATE users `users` SET FirstName=%s,FamilyName=%s,Email=%s,DateOfBirth=%s,Password=%s WHERE ID=%s"
					val=(first_name,family_name,email,dob,password, user_id)
					cursor.execute(sql,(val))
					data = cursor.fetchall()
					data=list(data)
					#save values in dbase
				connection.commit()
				cursor.close()
			finally:
				connection.close()
			return redirect(url_for('hello'))
	try:
		
		with connection.cursor() as cursor:
			#pull records and display
			sql = "SELECT * from users where ID=%s"
			cursor.execute(sql, user_id)
			data = cursor.fetchone()
			data=data
	finally:
		connection.close()
	return render_template("Edit_record.html",data=data)


@app.route('/edit_workshop', methods=['POST','GET'])
def update_workshop():
	id = request.args.get('id')
	connection=create_connection()
	if request.method == 'POST':
			form_values = request.form 

			id = form_values.get('id')
			title = form_values.get("title")
			date = form_values.get("date")
			room = form_values.get("room")
			subject = form_values.get("subject")
			teacher = form_values.get("teacher")

			try:
				with connection.cursor() as cursor:
					# Create a new record
					sql = "UPDATE workshops `workshops` SET Title=%s,Date=%s,Room=%s,Subject=%s,Teacher=%s WHERE WorkshopID=%s"
					val=(title,date,room,subject,teacher,id)
					cursor.execute(sql,(val))
					data = cursor.fetchall()
					data=list(data)
					#save values in dbase
				connection.commit()
				cursor.close()
			finally:
				connection.close()
			return redirect(url_for('home'))
	try:
		
		with connection.cursor() as cursor:
			#pull records and display
			sql = "SELECT * from workshops WHERE WorkshopID=%s"
			cursor.execute(sql,(id))
			data = cursor.fetchone()
			data=data
	finally:
		connection.close()
	return render_template("Edit_workshop.html",data=data)
# Tasks 
# Per assessment AS91902 Document; complex techniques  include creating queries which insert, update or delete to modify data
#so you should add  new routes for edit_user, user_details and delete_user using record ids
# create the html pages needed
# modify database to include an image field which will store the image filename(eg pic.jpg) in database and  implement this functionality in code where applicable

@app.route('/delete_record', methods=['POST','GET'])
def delete_record():
	user_ID = request.args.get('id')
	connection=create_connection()
	if request.method == 'POST':
		form_values = request.form 
		try:
			with connection.cursor() as cursor:
				# Create a new record
				sql = "DELETE FROM `users` WHERE ID=%s"
				val=(user_ID)
				cursor.execute(sql,(val))
				data = cursor.fetchall()
				data=list(data)
			#save values in dbase
			connection.commit()
			cursor.close()
		finally:
			connection.close()
			return redirect(url_for('home'))
	try:
		with connection.cursor() as cursor:
			#pull records and display
			sql = "SELECT * from users where ID=%s"
			cursor.execute(sql, user_ID)
			data = cursor.fetchone()
			data=data
	finally:
		connection.close()
	return render_template("delete_record.html",data=data)

@app.route('/delete_workshop', methods=['POST','GET'])
def delete_workshop():
	workshop_Id = request.args.get('id')
	connection=create_connection()
	if request.method == 'POST':
		form_values = request.form 
		try:
			with connection.cursor() as cursor:
				# Create a new record
				sql = "DELETE FROM `workshops` WHERE WorkshopID = %s"
				val=(workshop_Id)
				cursor.execute(sql,(val))
				data = cursor.fetchall()
				data=list(data)
			#save values in dbase
			connection.commit()
			cursor.close()
		finally:
			connection.close()
			return redirect(url_for('workshops'))
	try:
		with connection.cursor() as cursor:
			#pull records and display
			sql = "SELECT * from workshops where WorkshopID = %s"
			cursor.execute(sql, workshop_Id)
			data = cursor.fetchone()
			data=data
	finally:
		connection.close()
	return render_template("delete_workshop.html",data=data)

#login
@app.route('/login', methods=['GET', 'POST'])
def login():
    connection=create_connection()
    if  session.get('logged_in'):
        display_all_records()
        username_session=escape(session['username']).capitalize()
        return redirect(url_for("index", results=data,session_user_name=username_session))
    error = None
    try:
        with connection.cursor() as cursor:
         if request.method == 'POST':
            username_form  = request.form['username']
            select_sql = "SELECT COUNT(1) FROM users WHERE UserName = %s"
            val =(username_form)
            cursor.execute(select_sql,val)
            #data = cursor.fetchall()

            if not list(cursor.fetchone())[0]:
                raise ServerError('Invalid username')

            password_form  = request.form['password']
            select_sql = "SELECT RoleID,ID,Password from users WHERE UserName = %s"
            val=(username_form)
            cursor.execute(select_sql,val)
            data = list(cursor.fetchall())
            print (data)
            for row in data:
                #print(md5(password_form.encode()).hexdigest())
                if md5(password_form.encode()).hexdigest()==row['Password']:
                    session['username'] = request.form['username']
                    session['logged_in'] = True
                    session['ID']=row['ID']
                    session['RoleID']=row['RoleID']
                    return redirect(url_for('home'))

            raise ServerError('Invalid password')
    except ServerError as e:
        error = str(e)
        session['logged_in']=False

    return render_template('Login.html', error=error)

def display_all_records(role="admin",Id=0):
	global data
	connection=create_connection()
	try:
		with connection.cursor() as cursor:
			#pull records and display using a left join
			#select_sql = *SELECT* from users
			#if role not *admin*
			select_sql = "SELECT users.Id As Id,users.Email AS Email,users.FirstName AS FirstName, users.FamilyName As"
			if int(Id)>0:
				print(select_sql)
				print(Id)
				select_sql = select_sql+" Where users Id="+Id
				val=(int(Id))
				print(select_sql)
				cursor.execute(select_sql)
				data = cursor.fetchall()
				data=list(data)
	finally:
		connection.close()

@app.route('/logout')
def logout():
    session.pop('username', None)
    session['logged_in'] = False
    return redirect(url_for('home'))



if __name__ == '__main__':
	app.secret_key = os.urandom(12)
	class ServerError(Exception):pass
	import os
	HOST = os.environ.get('SERVER_HOST', 'localhost')
	try:
		PORT = int(os.environ.get('SERVER_PORT', '5555'))
	except ValueError:
		PORT = 5555
	app.run(HOST, PORT, debug=True)


